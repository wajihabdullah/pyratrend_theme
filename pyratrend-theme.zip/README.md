# Pyratrend Custom Theme

A minimal but valid Shopify theme (`layout`, all `templates`, `snippets`,
`assets`, `config`, `locales`) used for **Scenario B: whole-store builds**.

## What it does

- The **product template** (`templates/product.liquid`) renders the AI-generated
  full-page design stored in the product metafield `pyratrend.page_html` with
  full Liquid/CSS/JS freedom (no `descriptionHtml` sanitizer).
  - It injects `window.__PYRA__ = { variant, url }` so the design's buy buttons
    work (`/cart/add?id=<variant>&quantity=1`).
  - If a product has no design metafield, it renders a clean built-in product
    layout (gallery, title, price, variant select, add-to-cart).
- Every other template (home, collection, cart, search, pages, blog, etc.) is a
  functioning storefront styled by the same design system (`assets/pyratrend.css`,
  brand colors exposed as theme settings in `config/settings_schema.json`).

## Installing it on a store

1. **Host a ZIP of this directory at a public HTTPS URL.** Shopify fetches the
   ZIP from its own servers, so a `localhost` URL will NOT work. Set it as
   `app.shopify.custom-theme-zip-url` in the prototype backend config.
2. The backend installs it via the sanctioned path: `POST /themes.json`
   `{ theme: { name, src: <zip url> } }` → `PUT /themes/{id}.json` role `main`.
   No "theme files" exemption is needed for creating a theme from a ZIP.

## ⚠️ MUST-FIND LATER — Scenario A (do not lose this)

This custom theme **replaces the merchant's whole theme**, so it is only right
when we are building a store from scratch. A core product requirement is to ALSO
support merchants who **keep their existing theme + whole store design and only
want a designed PRODUCT PAGE**. Shopify blocks non-exempt custom apps from
writing theme files (REST assets + GraphQL `themeFilesUpsert` are both denied),
so Scenario A must be delivered via:

- a **Theme App Extension** (app block the merchant adds to the product
  template), or
- a **script-tag overlay** (Script Tags API, needs `write_script_tags` scope +
  public HTTPS backend).

Do not build further assuming this zip-install is the only delivery mechanism.
Keep the page spec + `FullPageRenderer` theme-agnostic so the same design HTML
works in the custom theme AND in an app block.
