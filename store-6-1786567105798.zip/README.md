# Pyratrend Custom Theme (Dawn-based)

A fork of Shopify's open-source **Dawn** theme (MIT licensed — see `LICENSE.md`)
used for **Scenario B: whole-store builds**. Dawn provides a battle-tested,
responsive (mobile + desktop) storefront: cart drawer, predictive search,
product gallery/lightbox, variant pickers, dynamic checkout, blogs, and every
standard template. We only add ONE thing on top:

## The product page

`sections/pyra-product-page.liquid` is injected at the top of
`templates/product.json`:

- If the product has a `pyratrend.page_html` metafield (our AI-generated
  full-page design), it renders that design with full CSS/JS and **hides the
  stock Dawn product sections** via CSS (`#shopify-section-main`,
  `#shopify-section-disclosures`, `#shopify-section-related-products`) — no
  flash of the default layout.
- If a product has NO design, the section renders nothing and the full Dawn
  product experience shows unchanged. Every product page always works.
- Buy buttons in the design are wired via `window.__PYRA__ = { variant, url }`
  injected by the section.

## Building / shipping the ZIP

1. Make theme changes under this folder.
2. Rebuild `pyratrend-theme.zip` with FORWARD-SLASH entry names (Windows
   `Compress-Archive` stores backslashes and Shopify rejects the theme). A
   helper is at `../ZipTheme.java`.
3. Push the zip from `pyra-theme-git/` (the repo only tracks the zip):
   `git add pyratrend-theme.zip && git commit && git push`.
4. jsDelivr caches ~12h — pin the URL to the new commit SHA
   (`https://cdn.jsdelivr.net/gh/wajihabdullah/pyratrend_theme@<sha>/pyratrend-theme.zip`)
   or use a new filename to bypass the cache immediately.

## ⚠️ MUST-FIND LATER — Scenario A (do not lose this)

This Dawn-based theme **replaces the merchant's whole theme**, so it is only
right when we are building a store from scratch. A core product requirement is
to ALSO support merchants who **keep their existing theme + whole store design
and only want a designed PRODUCT PAGE**. Shopify blocks non-exempt custom apps
from writing theme files (REST assets + GraphQL `themeFilesUpsert` are both
denied), so Scenario A must be delivered via:

- a **Theme App Extension** (app block the merchant adds to the product
  template), or
- a **script-tag overlay** (Script Tags API, needs `write_script_tags` scope +
  public HTTPS backend).

Keep the page spec + `FullPageRenderer` theme-agnostic so the same design HTML
works in this Dawn theme AND in an app block. This requirement is also
documented in `sections/pyra-product-page.liquid`, `FullPageRenderer.java`, and
`ThemeService.java`.
